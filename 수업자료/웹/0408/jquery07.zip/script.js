$("#partner").click(function(){
	$("#modal").fadeIn(1000);
});
$("#modal .body img").click(function(){
	$("#modal").fadeOut(1000);
})