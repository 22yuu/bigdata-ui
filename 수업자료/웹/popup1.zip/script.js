$("#partner").click(function(){
	$("#partner_up").addClass("active");
});
$("#partner_up .btnClose").click(function(){
	$("#partner_up").removeClass("active");
});